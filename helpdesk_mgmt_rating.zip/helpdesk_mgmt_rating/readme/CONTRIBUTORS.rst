* `Domatix <https://www.domatix.com>`_:

  * Samuel Calvo

* `Obertix <https://obertix.net>`_:

  * Vicent Cubells <vicent@vcubells.net>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
